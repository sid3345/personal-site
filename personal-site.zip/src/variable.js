module.exports = {
name : 'Siddharth Sinha',
'position': 'Full Stack Developer',
linkedin : 'https://www.linkedin.com/in/sid3345/',
hackerearth: 'https://www.hackerearth.com/@sid3345',
hackerrank: '',
github: 'https://github.com/sid3345',
instagram: '',
mail:'mailto:sid3345@gmail.com',
image:'img/Siddharth.jpg',
contact: 9967363998,
address: 'Mumbai',
company: 'Airbus'
}