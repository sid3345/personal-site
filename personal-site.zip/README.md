Open the project in vscode

Open Terminal

Type the below commands

$ npm install

$ npm start

That's all !
